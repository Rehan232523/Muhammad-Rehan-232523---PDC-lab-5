﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    // You can override these values from the command line.
    // Defaults correspond to the 1 / 1 / 8 configuration.
    const int NUM_PRODUCERS = 1;
    const int NUM_CONSUMERS = 1;
    const int BUFFER_SIZE = 8;
    const int ITEMS_PER_PRODUCER = 10000;

    static readonly int[] buffer = new int[BUFFER_SIZE];

    static int inPos = 0;
    static int outPos = 0;

    // Protects the circular buffer and indexes.
    static readonly Mutex bufLock = new Mutex();

    // Counting semaphores.
    // emptySlots = number of free buffer positions.
    // fullSlots  = number of occupied buffer positions.
    static readonly Semaphore emptySlots =
        new Semaphore(BUFFER_SIZE, BUFFER_SIZE);

    static readonly Semaphore fullSlots =
        new Semaphore(0, BUFFER_SIZE);

    // Each produced item gets a unique global ID.
    static readonly int totalItems =
        NUM_PRODUCERS * ITEMS_PER_PRODUCER;

    // 0 = never consumed
    // 1 = consumed exactly once
    // >1 = duplicated
    static readonly int[] seen = new int[totalItems];

    static long duplicateCount = 0;
    static long invalidCount = 0;

    static void Producer(object? obj)
    {
        int producerId = (int)obj!;

        for (int i = 0; i < ITEMS_PER_PRODUCER; i++)
        {
            // Each producer owns a separate range of item IDs.
            int item = producerId * ITEMS_PER_PRODUCER + i;

            // Correct order:
            // 1. Wait for an empty slot.
            // 2. Lock buffer.
            // 3. Insert item.
            // 4. Unlock buffer.
            // 5. Signal a full slot.
            emptySlots.WaitOne();

            bufLock.WaitOne();

            buffer[inPos] = item;
            inPos = (inPos + 1) % BUFFER_SIZE;

            bufLock.ReleaseMutex();

            fullSlots.Release();
        }
    }

    static void Consumer(object? obj)
    {
        int itemsToConsume = totalItems / NUM_CONSUMERS;

        // If totalItems is not evenly divisible, the first consumers
        // can receive one extra item.
        int consumerId = (int)obj!;
        int remainder = totalItems % NUM_CONSUMERS;

        if (consumerId < remainder)
            itemsToConsume++;

        for (int i = 0; i < itemsToConsume; i++)
        {
            // Correct order:
            // 1. Wait for a full slot.
            // 2. Lock buffer.
            // 3. Remove item.
            // 4. Unlock buffer.
            // 5. Signal an empty slot.
            fullSlots.WaitOne();

            bufLock.WaitOne();

            int item = buffer[outPos];
            outPos = (outPos + 1) % BUFFER_SIZE;

            bufLock.ReleaseMutex();

            emptySlots.Release();

            // Check the item after releasing the mutex.
            if (item < 0 || item >= totalItems)
            {
                Interlocked.Increment(ref invalidCount);
            }
            else
            {
                int oldValue = Interlocked.Increment(ref seen[item]);

                if (oldValue > 1)
                    Interlocked.Increment(ref duplicateCount);
            }
        }
    }

    static void Main()
    {
        Thread[] producers = new Thread[NUM_PRODUCERS];
        Thread[] consumers = new Thread[NUM_CONSUMERS];

        Stopwatch stopwatch = Stopwatch.StartNew();

        // Create producers.
        for (int i = 0; i < NUM_PRODUCERS; i++)
        {
            int id = i;

            producers[i] = new Thread(() => Producer(id));
            producers[i].Start();
        }

        // Create consumers.
        for (int i = 0; i < NUM_CONSUMERS; i++)
        {
            int id = i;

            consumers[i] = new Thread(() => Consumer(id));
            consumers[i].Start();
        }

        // Wait for producers.
        foreach (Thread producer in producers)
            producer.Join();

        // Wait for consumers.
        foreach (Thread consumer in consumers)
            consumer.Join();

        stopwatch.Stop();

        int lost = 0;

        for (int i = 0; i < totalItems; i++)
        {
            if (seen[i] == 0)
                lost++;
        }

        bool passed =
            lost == 0 &&
            duplicateCount == 0 &&
            invalidCount == 0;

        Console.WriteLine("==========================================");
        Console.WriteLine(" Multiple Producer / Consumer Semaphore");
        Console.WriteLine("==========================================");
        Console.WriteLine($"Producers          : {NUM_PRODUCERS}");
        Console.WriteLine($"Consumers          : {NUM_CONSUMERS}");
        Console.WriteLine($"Buffer size        : {BUFFER_SIZE}");
        Console.WriteLine($"Items/producer     : {ITEMS_PER_PRODUCER}");
        Console.WriteLine($"Total items        : {totalItems}");
        Console.WriteLine($"Lost               : {lost}");
        Console.WriteLine($"Duplicated         : {duplicateCount}");
        Console.WriteLine($"Invalid items      : {invalidCount}");
        Console.WriteLine($"Time (ms)          : {stopwatch.Elapsed.TotalMilliseconds:F3}");
        Console.WriteLine(
            $"Result             : {(passed ? "PASS" : "FAIL")}");
    }
}
