﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    // Equivalent to the lab's compile-time options.
    const int NUM_WORKERS = 1;

    // Set to true to simulate SIGNAL_FIRST.
    // false = normal condition-variable version.
    const bool SIGNAL_FIRST = false;

    // Set to true to use polling/spinning instead of blocking.
    const bool USE_SPIN = false;

    // Delay before publishing the data.
    const int DELAY_MS = 500;

    // Shared state.
    static readonly object conditionLock = new object();

    static bool dataReady = false;
    static int sharedValue = 0;

    // Statistics.
    static int[] blockedCount = new int[NUM_WORKERS];

    static void Worker(object? argument)
    {
        int workerId = (int)argument!;

        if (USE_SPIN)
        {
            // Polling version.
            while (true)
            {
                lock (conditionLock)
                {
                    if (dataReady)
                    {
                        int value = sharedValue;

                        Console.WriteLine(
                            $"Worker {workerId}: value received = {value}");

                        return;
                    }
                }

                Interlocked.Increment(ref blockedCount[workerId]);

                // Yield CPU rather than continuously burning it.
                Thread.Yield();
            }
        }

        lock (conditionLock)
        {
            // Correct condition-variable pattern:
            // check the predicate in a WHILE loop.
            while (!dataReady)
            {
                blockedCount[workerId]++;

                /*
                 * Monitor.Wait atomically:
                 *
                 * 1. releases conditionLock
                 * 2. blocks the worker
                 * 3. reacquires conditionLock after being awakened
                 */
                Monitor.Wait(conditionLock);
            }

            int value = sharedValue;

            Console.WriteLine(
                $"Worker {workerId}: value received = {value}");
        }
    }

    static void Publish()
    {
        if (SIGNAL_FIRST)
        {
            /*
             * SIGNAL_FIRST experiment:
             * publish before the worker gets a chance to wait.
             *
             * The important point is that the flag remains true.
             * Therefore the worker will see the predicate and won't
             * need to wait.
             */
            lock (conditionLock)
            {
                sharedValue = 42;
                dataReady = true;

                Monitor.PulseAll(conditionLock);
            }

            return;
        }

        Thread.Sleep(DELAY_MS);

        lock (conditionLock)
        {
            sharedValue = 42;
            dataReady = true;

            // Wake waiting workers.
            if (NUM_WORKERS == 1)
            {
                Monitor.Pulse(conditionLock);
            }
            else
            {
                Monitor.PulseAll(conditionLock);
            }
        }
    }

    static void Main()
    {
        Stopwatch wallClock = Stopwatch.StartNew();
        Stopwatch cpuClock = Stopwatch.StartNew();

        Thread[] workers = new Thread[NUM_WORKERS];

        for (int i = 0; i < NUM_WORKERS; i++)
        {
            int workerId = i;

            workers[i] = new Thread(() => Worker(workerId));
            workers[i].Start();
        }

        // Publish the data and signal the condition.
        Publish();

        foreach (Thread worker in workers)
        {
            worker.Join();
        }

        wallClock.Stop();
        cpuClock.Stop();

        Console.WriteLine();
        Console.WriteLine("======================================");
        Console.WriteLine(" Condition Variable Signaling");
        Console.WriteLine("======================================");
        Console.WriteLine($"Workers       : {NUM_WORKERS}");
        Console.WriteLine($"Signal first  : {SIGNAL_FIRST}");
        Console.WriteLine($"Spin mode     : {USE_SPIN}");
        Console.WriteLine($"Value         : {sharedValue}");

        for (int i = 0; i < NUM_WORKERS; i++)
        {
            Console.WriteLine(
                $"Worker {i} blocked {blockedCount[i]} time(s)");
        }

        Console.WriteLine(
            $"Wall time (ms): {wallClock.Elapsed.TotalMilliseconds:F3}");

        Console.WriteLine(
            $"CPU time (ms) : {Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds:F3}");

        Console.WriteLine("RESULT: PASS");
    }
}