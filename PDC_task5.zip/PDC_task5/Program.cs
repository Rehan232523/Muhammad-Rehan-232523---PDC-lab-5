﻿using System;
using System.Diagnostics;
using System.Threading;

class Node
{
    public int Value;
    public Node? Next;

    public Node(int value)
    {
        Value = value;
        Next = null;
    }
}

class LockFreeStack
{
    // The top of the stack.
    private Node? top = null;

    /*
     * Lock-free push using CAS.
     *
     * Repeatedly:
     *   1. Read current top.
     *   2. Make the new node point to it.
     *   3. CAS top from oldTop to newNode.
     *   4. If another thread changed top, retry.
     */
    public void Push(Node node)
    {
        while (true)
        {
            Node? oldTop = Volatile.Read(ref top);

            node.Next = oldTop;

            Node? result =
                Interlocked.CompareExchange(
                    ref top,
                    node,
                    oldTop);

            if (result == oldTop)
                return;

            // Another thread changed top.
            // Retry the operation.
            Thread.Yield();
        }
    }

    /*
     * Lock-free pop using CAS.
     *
     * Repeatedly:
     *   1. Read current top.
     *   2. Read its next node.
     *   3. CAS top from oldTop to next.
     *   4. If another thread changed top, retry.
     */
    public Node? Pop()
    {
        while (true)
        {
            Node? oldTop = Volatile.Read(ref top);

            if (oldTop == null)
                return null;

            Node? newTop = oldTop.Next;

            Node? result =
                Interlocked.CompareExchange(
                    ref top,
                    newTop,
                    oldTop);

            if (result == oldTop)
                return oldTop;

            // Another thread changed top.
            // Retry.
            Thread.Yield();
        }
    }

    public bool IsEmpty()
    {
        return Volatile.Read(ref top) == null;
    }
}

class Program
{
    const int NUM_THREADS = 4;
    const int NODES_PER_THREAD = 10000;

    static readonly LockFreeStack stack = new LockFreeStack();

    // 0 = not popped
    // 1 = popped exactly once
    // >1 = duplicated
    static readonly int[] seen =
        new int[NUM_THREADS * NODES_PER_THREAD];

    static long duplicateCount = 0;
    static long invalidCount = 0;

    static void Worker(object? argument)
    {
        int threadId = (int)argument!;

        int start =
            threadId * NODES_PER_THREAD;

        int end =
            start + NODES_PER_THREAD;

        /*
         * Push this thread's unique nodes.
         */
        for (int i = start; i < end; i++)
        {
            stack.Push(new Node(i));
        }

        /*
         * Pop nodes.
         *
         * Multiple threads compete to remove nodes.
         * A failed CAS automatically retries inside Pop().
         */
        while (true)
        {
            Node? node = stack.Pop();

            if (node == null)
                break;

            int value = node.Value;

            if (value < 0 ||
                value >= seen.Length)
            {
                Interlocked.Increment(ref invalidCount);
                continue;
            }

            int oldValue =
                Interlocked.Increment(ref seen[value]);

            if (oldValue > 1)
            {
                Interlocked.Increment(ref duplicateCount);
            }
        }
    }

    static void Main()
    {
        int totalNodes =
            NUM_THREADS * NODES_PER_THREAD;

        Thread[] threads =
            new Thread[NUM_THREADS];

        Stopwatch stopwatch =
            Stopwatch.StartNew();

        /*
         * Create worker threads.
         */
        for (int i = 0; i < NUM_THREADS; i++)
        {
            int threadId = i;

            threads[i] =
                new Thread(() => Worker(threadId));

            threads[i].Start();
        }

        /*
         * Wait for all workers.
         */
        foreach (Thread thread in threads)
        {
            thread.Join();
        }

        stopwatch.Stop();

        /*
         * Count nodes that were never popped.
         */
        int lostCount = 0;

        for (int i = 0; i < totalNodes; i++)
        {
            if (seen[i] == 0)
                lostCount++;
        }

        bool stackEmpty =
            stack.IsEmpty();

        bool passed =
            lostCount == 0 &&
            duplicateCount == 0 &&
            invalidCount == 0 &&
            stackEmpty;

        Console.WriteLine("==========================================");
        Console.WriteLine(" Lock-Free Stack / CAS");
        Console.WriteLine("==========================================");
        Console.WriteLine($"Threads          : {NUM_THREADS}");
        Console.WriteLine($"Nodes/thread     : {NODES_PER_THREAD}");
        Console.WriteLine($"Total nodes      : {totalNodes}");
        Console.WriteLine($"Lost             : {lostCount}");
        Console.WriteLine($"Duplicated       : {duplicateCount}");
        Console.WriteLine($"Invalid          : {invalidCount}");
        Console.WriteLine($"Stack empty      : {(stackEmpty ? "Y" : "N")}");
        Console.WriteLine(
            $"Time (ms)        : {stopwatch.Elapsed.TotalMilliseconds:F3}");
        Console.WriteLine(
            $"Result           : {(passed ? "PASS" : "FAIL")}");
    }
}