﻿using System;
using System.Diagnostics;
using System.Threading;

class PhaseBarrier
{
    // Number of threads required at the barrier.
    private readonly int parties;

    // Number of threads currently waiting in this generation.
    private int waiting = 0;

    // Changes every time all threads pass the barrier.
    private int generation = 0;

    private readonly object barrierLock = new object();

    public PhaseBarrier(int parties)
    {
        if (parties <= 0)
            throw new ArgumentOutOfRangeException(nameof(parties));

        this.parties = parties;
    }

    public void BarrierWait()
    {
        lock (barrierLock)
        {
            int myGeneration = generation;

            waiting++;

            if (waiting == parties)
            {
                // Last thread arrives.
                // Start the next generation.
                waiting = 0;
                generation++;

                // Wake all threads waiting in this generation.
                Monitor.PulseAll(barrierLock);
            }
            else
            {
                // Wait until this particular generation has finished.
                while (myGeneration == generation)
                {
                    Monitor.Wait(barrierLock);
                }
            }
        }
    }
}

class Program
{
    const int NUM_WORKERS = 4;
    const int ROUNDS = 10000;
    const int ARRAY_SIZE = 1000;

    static readonly int[] data = new int[ARRAY_SIZE];

    static readonly PhaseBarrier barrier =
        new PhaseBarrier(NUM_WORKERS);

    static void Worker(object? argument)
    {
        int workerId = (int)argument!;

        for (int round = 0; round < ROUNDS; round++)
        {
            /*
             * Each worker modifies its own portion of the array.
             *
             * The calculation is deterministic so that the result
             * can be checked after all phases have completed.
             */
            int start =
                workerId * ARRAY_SIZE / NUM_WORKERS;

            int end =
                (workerId + 1) * ARRAY_SIZE / NUM_WORKERS;

            for (int i = start; i < end; i++)
            {
                data[i] += 1;
            }

            /*
             * Barrier #1:
             *
             * All workers must finish their calculation for this
             * round before any worker starts the next phase.
             */
            barrier.BarrierWait();

            /*
             * Second phase.
             *
             * Every worker can safely observe the completed state
             * from the previous phase.
             */
            for (int i = start; i < end; i++)
            {
                // Read the value to prevent the phase from becoming
                // a meaningless empty computation.
                int value = data[i];

                if (value < 0)
                {
                    Console.WriteLine(
                        $"Unexpected value at index {i}");
                }
            }

            /*
             * Barrier #2:
             *
             * Prevents a fast worker from beginning the next round
             * while another worker is still using the current round's
             * data.
             */
            barrier.BarrierWait();
        }
    }

    static bool CheckResult()
    {
        int expected = ROUNDS;

        for (int i = 0; i < ARRAY_SIZE; i++)
        {
            if (data[i] != expected)
            {
                Console.WriteLine(
                    $"Mismatch at index {i}: " +
                    $"expected {expected}, got {data[i]}");

                return false;
            }
        }

        return true;
    }

    static void Main()
    {
        Thread[] workers =
            new Thread[NUM_WORKERS];

        Stopwatch stopwatch =
            Stopwatch.StartNew();

        for (int i = 0; i < NUM_WORKERS; i++)
        {
            int workerId = i;

            workers[i] =
                new Thread(() => Worker(workerId));

            workers[i].Start();
        }

        foreach (Thread worker in workers)
        {
            worker.Join();
        }

        stopwatch.Stop();

        bool correct = CheckResult();

        Console.WriteLine("======================================");
        Console.WriteLine(" Reusable Phase Barrier");
        Console.WriteLine("======================================");
        Console.WriteLine($"Workers       : {NUM_WORKERS}");
        Console.WriteLine($"Rounds        : {ROUNDS}");
        Console.WriteLine($"Array size    : {ARRAY_SIZE}");
        Console.WriteLine($"Correct       : {(correct ? "Y" : "N")}");
        Console.WriteLine(
            $"Time (ms)     : {stopwatch.Elapsed.TotalMilliseconds:F3}");
    }
}
