﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    // Change these with command-line arguments if desired.
    const int BUFFER_SIZE = 8;
    const int ITEMS = 100000;

    // Shared bounded circular buffer
    static readonly int[] buffer = new int[BUFFER_SIZE];

    static int inPos = 0;
    static int outPos = 0;
    static int count = 0;

    // Mutex protects buffer, positions, and count
    static readonly Mutex mutex = new Mutex();

    // Statistics
    static long producerRetries = 0;
    static long consumerRetries = 0;
    static int orderErrors = 0;
    static long checksumProduced = 0;
    static long checksumConsumed = 0;

    static void Producer()
    {
        for (int item = 0; item < ITEMS;)
        {
            mutex.WaitOne();

            if (count < BUFFER_SIZE)
            {
                // Critical section
                buffer[inPos] = item;
                inPos = (inPos + 1) % BUFFER_SIZE;
                count++;

                checksumProduced += item;

                mutex.ReleaseMutex();

                item++;
            }
            else
            {
                // Buffer full
                mutex.ReleaseMutex();

                Interlocked.Increment(ref producerRetries);

                // Equivalent idea to sched_yield()
                Thread.Yield();
            }
        }
    }

    static void Consumer()
    {
        for (int expected = 0; expected < ITEMS;)
        {
            mutex.WaitOne();

            if (count > 0)
            {
                // Critical section
                int item = buffer[outPos];
                outPos = (outPos + 1) % BUFFER_SIZE;
                count--;

                checksumConsumed += item;

                mutex.ReleaseMutex();

                // Verify FIFO order
                if (item != expected)
                {
                    Interlocked.Increment(ref orderErrors);
                }

                expected++;
            }
            else
            {
                // Buffer empty
                mutex.ReleaseMutex();

                Interlocked.Increment(ref consumerRetries);

                Thread.Yield();
            }
        }
    }

    static void Main()
    {
        Stopwatch stopwatch = Stopwatch.StartNew();

        Thread producer = new Thread(Producer);
        Thread consumer = new Thread(Consumer);

        producer.Start();
        consumer.Start();

        producer.Join();
        consumer.Join();

        stopwatch.Stop();

        bool checksumOK = checksumProduced == checksumConsumed;
        bool orderOK = orderErrors == 0;
        bool bufferEmpty = count == 0;

        Console.WriteLine("=== Mutex-Protected Bounded Buffer ===");
        Console.WriteLine($"Buffer size       : {BUFFER_SIZE}");
        Console.WriteLine($"Items             : {ITEMS}");
        Console.WriteLine($"Produced checksum : {checksumProduced}");
        Console.WriteLine($"Consumed checksum : {checksumConsumed}");
        Console.WriteLine($"Checksum OK       : {(checksumOK ? "Y" : "N")}");
        Console.WriteLine($"Order errors      : {orderErrors}");
        Console.WriteLine($"Producer retries  : {producerRetries}");
        Console.WriteLine($"Consumer retries  : {consumerRetries}");
        Console.WriteLine($"Buffer empty      : {(bufferEmpty ? "Y" : "N")}");
        Console.WriteLine($"Time (ms)         : {stopwatch.Elapsed.TotalMilliseconds:F3}");

        if (checksumOK && orderOK && bufferEmpty)
        {
            Console.WriteLine("RESULT: PASS - no items lost, duplicated, or reordered.");
        }
        else
        {
            Console.WriteLine("RESULT: FAIL");
        }
    }
}